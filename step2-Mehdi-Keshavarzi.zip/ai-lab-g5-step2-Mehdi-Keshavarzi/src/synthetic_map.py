"""Generate a deterministic synthetic road grid for routing experiments.

Author: Mehdi Keshavarzi (Coding / Step 2)

This is a test network, not a representation or survey of real Shiraz streets.
"""
from __future__ import annotations

import argparse
import math
from pathlib import Path

import networkx as nx

try:  # Supports both `python -m src.synthetic_map` and direct script execution.
    from .graph_builder import save_graphml
except ImportError:  # pragma: no cover - exercised when run as a script
    from graph_builder import save_graphml


EARTH_RADIUS_M = 6_371_000.0
DEFAULT_ORIGIN_LAT = 29.5918
DEFAULT_ORIGIN_LON = 52.5836


def _meters_to_degrees(latitude: float, distance_m: float) -> tuple[float, float]:
    """Approximate latitude/longitude degree offsets for a local grid."""
    latitude_delta = (distance_m / EARTH_RADIUS_M) * (180.0 / 3.141592653589793)
    cosine = max(abs(math.cos(math.radians(latitude))), 1e-8)
    longitude_delta = latitude_delta / cosine
    return latitude_delta, longitude_delta


def build_synthetic_map(
    *,
    rows: int = 8,
    cols: int = 8,
    spacing_m: float = 120.0,
    origin_lat: float = DEFAULT_ORIGIN_LAT,
    origin_lon: float = DEFAULT_ORIGIN_LON,
) -> nx.MultiDiGraph:
    """Build a bidirectional, grid-shaped synthetic road graph.

    Node IDs are stable integers (row * cols + col). Coordinates use the
    project's convention: x=longitude, y=latitude. Every connection is
    represented by two directed edges, one in each direction.
    """
    if rows < 2 or cols < 2:
        raise ValueError("rows and cols must both be at least 2.")
    if not math.isfinite(spacing_m) or spacing_m <= 0:
        raise ValueError("spacing_m must be a finite positive number.")
    if not -90 <= origin_lat <= 90:
        raise ValueError("origin_lat must be between -90 and 90 degrees.")
    if not -180 <= origin_lon <= 180:
        raise ValueError("origin_lon must be between -180 and 180 degrees.")

    lat_step, lon_step = _meters_to_degrees(origin_lat, spacing_m)
    graph = nx.MultiDiGraph(
        crs="EPSG:4326",
        graph_source="synthetic",
        network_type="synthetic_grid",
        weight_attribute="length",
        weight_unit="meters",
        synthetic=True,
        generated_by="synthetic_map.py",
        author="Mehdi Keshavarzi",
    )

    for row in range(rows):
        for col in range(cols):
            node_id = row * cols + col
            graph.add_node(
                node_id,
                osmid=node_id,
                x=origin_lon + col * lon_step,
                y=origin_lat - row * lat_step,
                grid_row=row,
                grid_col=col,
                synthetic=True,
            )

    # Add each horizontal and vertical street in both directions.
    for row in range(rows):
        for col in range(cols):
            u = row * cols + col
            neighbors: list[tuple[int, str]] = []
            if col + 1 < cols:
                neighbors.append((u + 1, "Horizontal"))
            if row + 1 < rows:
                neighbors.append((u + cols, "Vertical"))

            for v, street_orientation in neighbors:
                street_name = f"Synthetic {street_orientation} Street"
                common_attributes = {
                    "length": float(spacing_m),
                    "weight": float(spacing_m),
                    "highway": "residential",
                    "name": street_name,
                    "oneway": False,
                    "synthetic": True,
                }
                graph.add_edge(u, v, **common_attributes)
                graph.add_edge(v, u, **common_attributes)

    return graph


def main() -> None:
    project_root = Path(__file__).resolve().parents[1]
    default_output = project_root / "data" / "synthetic" / "shiraz_synthetic.graphml"

    parser = argparse.ArgumentParser(description="Generate a synthetic urban road grid.")
    parser.add_argument("--rows", type=int, default=8, help="Number of grid rows (default: 8)")
    parser.add_argument("--cols", type=int, default=8, help="Number of grid columns (default: 8)")
    parser.add_argument("--spacing", type=float, default=120.0, help="Street spacing in meters")
    parser.add_argument("--origin-lat", type=float, default=DEFAULT_ORIGIN_LAT)
    parser.add_argument("--origin-lon", type=float, default=DEFAULT_ORIGIN_LON)
    parser.add_argument("--output", type=Path, default=default_output)
    args = parser.parse_args()

    graph = build_synthetic_map(
        rows=args.rows,
        cols=args.cols,
        spacing_m=args.spacing,
        origin_lat=args.origin_lat,
        origin_lon=args.origin_lon,
    )
    output_path = save_graphml(graph, args.output)
    print(f"Saved synthetic graph: {output_path}")
    print(f"Nodes: {graph.number_of_nodes()} | Directed edges: {graph.number_of_edges()}")
    print("Source: synthetic (not actual Shiraz street data)")


if __name__ == "__main__":
    main()
