"""Download a real street network from OpenStreetMap using OSMnx.

Author: Mehdi Keshavarzi (Coding / Step 2)

The default query targets Shiraz, Fars Province, Iran. The exact study area
and travel mode remain configurable because the design document leaves them
for the team to confirm.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
from pathlib import Path

import networkx as nx

try:  # Supports both `python -m src.real_map_loader` and direct script execution.
    from .graph_builder import normalize_graph, save_graphml
except ImportError:  # pragma: no cover - exercised when run as a script
    from graph_builder import normalize_graph, save_graphml


DEFAULT_PLACE = "Shiraz, Fars Province, Iran"
DEFAULT_NETWORK_TYPE = "drive"
OSM_ATTRIBUTION = "© OpenStreetMap contributors"
OSM_SOURCE_URL = "https://www.openstreetmap.org/"
OSM_LICENSE = "Open Database License (ODbL)"


def _import_osmnx():
    try:
        import osmnx as ox
    except ImportError as exc:
        raise RuntimeError(
            "OSMnx is required to download real maps. Install dependencies with: "
            "python -m pip install -r requirements.txt"
        ) from exc
    return ox


def load_real_map(
    place: str = DEFAULT_PLACE,
    *,
    network_type: str = DEFAULT_NETWORK_TYPE,
    simplify: bool = True,
    retain_all: bool = False,
    custom_filter: str | None = None,
    use_cache: bool = True,
    requests_timeout: int = 180,
) -> nx.MultiDiGraph:
    """Download a directed OSM street graph for a geocodable place query.

    ``network_type='drive'`` is the current project proposal, not a final
    group decision. Choose ``walk`` if the team confirms pedestrian routing.
    """
    if not isinstance(place, str) or not place.strip():
        raise ValueError("place must be a non-empty geocodable place query.")
    if requests_timeout <= 0:
        raise ValueError("requests_timeout must be a positive integer.")

    ox = _import_osmnx()
    ox.settings.use_cache = use_cache
    ox.settings.requests_timeout = requests_timeout

    graph_options = {
        "network_type": network_type,
        "simplify": simplify,
        "retain_all": retain_all,
    }
    if custom_filter is not None:
        graph_options["custom_filter"] = custom_filter

    try:
        downloaded_graph = ox.graph_from_place(place.strip(), **graph_options)
    except Exception as exc:
        raise RuntimeError(
            f"Could not download the OSM network for {place!r}. Check the place name, "
            "internet connection, and Overpass/Nominatim availability."
        ) from exc

    graph = normalize_graph(downloaded_graph, source="openstreetmap")
    graph.graph.update(
        {
            "network_type": network_type,
            "download_query": place.strip(),
            "source_url": OSM_SOURCE_URL,
            "license": OSM_LICENSE,
            "attribution": OSM_ATTRIBUTION,
            "retrieved_at_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "weight_attribute": "length",
            "weight_unit": "meters",
            "simplified": bool(simplify),
            "retain_all": bool(retain_all),
            "custom_filter": custom_filter or "none",
            "downloaded_by": "Mehdi Keshavarzi",
        }
    )
    return graph


def download_and_save_real_map(
    place: str = DEFAULT_PLACE,
    *,
    network_type: str = DEFAULT_NETWORK_TYPE,
    output_path: str | Path | None = None,
    simplify: bool = True,
    retain_all: bool = False,
    custom_filter: str | None = None,
    use_cache: bool = True,
    requests_timeout: int = 180,
) -> tuple[nx.MultiDiGraph, Path]:
    """Download, normalize, and save an OSM street graph as GraphML."""
    project_root = Path(__file__).resolve().parents[1]
    if output_path is None:
        output_path = project_root / "data" / "real" / f"shiraz_{network_type}.graphml"

    graph = load_real_map(
        place,
        network_type=network_type,
        simplify=simplify,
        retain_all=retain_all,
        custom_filter=custom_filter,
        use_cache=use_cache,
        requests_timeout=requests_timeout,
    )
    saved_path = save_graphml(graph, output_path)
    return graph, saved_path


def main() -> None:
    project_root = Path(__file__).resolve().parents[1]
    default_output = project_root / "data" / "real" / "shiraz_drive.graphml"

    parser = argparse.ArgumentParser(description="Download a real OSM street network.")
    parser.add_argument("--place", default=DEFAULT_PLACE, help="Geocodable place query")
    parser.add_argument(
        "--network-type",
        choices=("drive", "drive_service", "walk", "bike", "all", "all_private"),
        default=DEFAULT_NETWORK_TYPE,
    )
    parser.add_argument("--output", type=Path, default=default_output)
    parser.add_argument("--retain-all", action="store_true")
    parser.add_argument("--no-cache", action="store_true")
    parser.add_argument("--timeout", type=int, default=180)
    args = parser.parse_args()

    graph, saved_path = download_and_save_real_map(
        args.place,
        network_type=args.network_type,
        output_path=args.output,
        retain_all=args.retain_all,
        use_cache=not args.no_cache,
        requests_timeout=args.timeout,
    )
    print(f"Saved OSM graph: {saved_path}")
    print(f"Nodes: {graph.number_of_nodes()} | Directed edges: {graph.number_of_edges()}")
    print(f"Network type: {args.network_type}")
    print(f"Attribution: {OSM_ATTRIBUTION}")
    print(f"Retrieved at (UTC): {graph.graph['retrieved_at_utc']}")


if __name__ == "__main__":
    main()
