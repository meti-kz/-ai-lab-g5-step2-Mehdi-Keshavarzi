"""Normalize, validate, and persist routing graphs for AI Lab G5.

Author: Mehdi Keshavarzi (Coding / Step 2)

The project's canonical representation is a directed, weighted
``networkx.MultiDiGraph``. The primary routing cost is ``length`` in meters.
"""
from __future__ import annotations

import copy
import json
import math
from pathlib import Path
from typing import Any

import networkx as nx


DEFAULT_WEIGHT_ATTRIBUTE = "length"
DEFAULT_WEIGHT_UNIT = "meters"
OSM_ATTRIBUTION = "© OpenStreetMap contributors"


def _as_finite_non_negative_number(value: Any, *, label: str) -> float:
    """Convert a value to float and reject invalid routing costs."""
    try:
        number = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{label} must be numeric; received {value!r}.") from exc
    if not math.isfinite(number) or number < 0:
        raise ValueError(f"{label} must be a finite, non-negative number; received {value!r}.")
    return number


def normalize_graph(
    graph: nx.Graph,
    *,
    source: str | None = None,
    require_coordinates: bool = True,
) -> nx.MultiDiGraph:
    """Return a canonical directed MultiDiGraph without mutating ``graph``.

    - Preserves parallel edges and their keys where available.
    - Converts undirected graphs to two-way directed graphs.
    - Standardizes coordinates to ``x`` (longitude) and ``y`` (latitude).
    - Ensures every edge has a non-negative ``length`` and matching ``weight``.
    """
    if not isinstance(graph, nx.Graph):
        raise TypeError("graph must be a NetworkX graph instance.")

    if isinstance(graph, nx.MultiDiGraph):
        normalized = copy.deepcopy(graph)
    elif graph.is_directed():
        normalized = nx.MultiDiGraph(graph)
    else:
        normalized = nx.MultiDiGraph(graph.to_directed())

    # Standardize graph-level metadata while preserving source metadata.
    normalized.graph.setdefault("crs", "EPSG:4326")
    normalized.graph.setdefault("weight_attribute", DEFAULT_WEIGHT_ATTRIBUTE)
    normalized.graph.setdefault("weight_unit", DEFAULT_WEIGHT_UNIT)
    normalized.graph["graph_format"] = "directed_multidigraph"
    if source is not None:
        normalized.graph["graph_source"] = source
    else:
        normalized.graph.setdefault("graph_source", "unspecified")

    for node_id, attributes in normalized.nodes(data=True):
        # OSMnx uses x/y. Accept common lon/lat aliases from other sources.
        if "x" not in attributes and "lon" in attributes:
            attributes["x"] = attributes["lon"]
        if "y" not in attributes and "lat" in attributes:
            attributes["y"] = attributes["lat"]
        if require_coordinates:
            missing = [name for name in ("x", "y") if name not in attributes]
            if missing:
                raise ValueError(
                    f"Node {node_id!r} is missing coordinate attribute(s): {', '.join(missing)}."
                )
        if "x" in attributes:
            attributes["x"] = float(attributes["x"])
        if "y" in attributes:
            attributes["y"] = float(attributes["y"])

    # MultiDiGraph.edges(keys=True, data=True) keeps parallel edges distinct.
    for u, v, key, attributes in normalized.edges(keys=True, data=True):
        if "length" not in attributes:
            if "weight" in attributes:
                attributes["length"] = attributes["weight"]
            else:
                raise ValueError(f"Edge ({u!r}, {v!r}, {key!r}) has no 'length' attribute.")
        length = _as_finite_non_negative_number(
            attributes["length"], label=f"length on edge ({u!r}, {v!r}, {key!r})"
        )
        attributes["length"] = length
        # Keep NetworkX algorithms and the project's schema consistent.
        attributes["weight"] = length

    return normalized


def validate_graph(
    graph: nx.Graph,
    *,
    require_coordinates: bool = True,
) -> dict[str, Any]:
    """Validate the project's graph contract and return a report dictionary."""
    errors: list[str] = []
    warnings: list[str] = []

    if not isinstance(graph, nx.MultiDiGraph):
        errors.append("Graph must be a directed NetworkX MultiDiGraph.")
    if graph.number_of_nodes() == 0:
        errors.append("Graph has no nodes.")
    if graph.number_of_edges() == 0:
        warnings.append("Graph has no edges; no route can be calculated.")

    for node_id, attributes in graph.nodes(data=True):
        if require_coordinates:
            for coordinate in ("x", "y"):
                if coordinate not in attributes:
                    errors.append(f"Node {node_id!r} is missing '{coordinate}'.")
                    break
                try:
                    value = float(attributes[coordinate])
                    if not math.isfinite(value):
                        raise ValueError
                except (TypeError, ValueError):
                    errors.append(f"Node {node_id!r} has an invalid '{coordinate}' coordinate.")
                    break

    if isinstance(graph, nx.MultiDiGraph):
        edge_iterator = graph.edges(keys=True, data=True)
    elif isinstance(graph, nx.MultiGraph):
        edge_iterator = graph.edges(keys=True, data=True)
    else:
        edge_iterator = ((u, v, 0, data) for u, v, data in graph.edges(data=True))

    for u, v, key, attributes in edge_iterator:
        try:
            _as_finite_non_negative_number(
                attributes.get("length"), label=f"length on edge ({u!r}, {v!r}, {key!r})"
            )
        except ValueError as exc:
            errors.append(str(exc))

    return {
        "valid": not errors,
        "errors": errors,
        "warnings": warnings,
        "node_count": graph.number_of_nodes(),
        "edge_count": graph.number_of_edges(),
        "graph_type": type(graph).__name__,
    }


def _to_graphml_scalar(value: Any) -> str | int | float | bool:
    """Convert complex attribute values to GraphML-compatible scalar values."""
    if value is None:
        return ""
    if isinstance(value, (str, int, float, bool)):
        return value
    # Shapely geometry is deliberately imported only if a geometry is encountered.
    if hasattr(value, "wkt"):
        return str(value.wkt)
    if isinstance(value, (list, tuple, set, dict)):
        serializable = sorted(value, key=str) if isinstance(value, set) else value
        return json.dumps(serializable, ensure_ascii=False, default=str)
    return str(value)


def _graphml_compatible_copy(graph: nx.MultiDiGraph) -> nx.MultiDiGraph:
    """Make a safe copy for NetworkX's built-in GraphML writer."""
    safe_graph = nx.MultiDiGraph()
    safe_graph.graph.update(
        {key: _to_graphml_scalar(value) for key, value in graph.graph.items()}
    )
    for node_id, attributes in graph.nodes(data=True):
        safe_graph.add_node(
            node_id,
            **{key: _to_graphml_scalar(value) for key, value in attributes.items()},
        )
    for u, v, key, attributes in graph.edges(keys=True, data=True):
        safe_graph.add_edge(
            u,
            v,
            key=key,
            **{name: _to_graphml_scalar(value) for name, value in attributes.items()},
        )
    return safe_graph


def save_graphml(
    graph: nx.Graph,
    filepath: str | Path,
    *,
    prefer_osmnx: bool = True,
) -> Path:
    """Normalize and save a graph as GraphML.

    OSMnx's serializer is preferred because it preserves OSMnx attribute types
    and geometry conventions. A NetworkX serializer fallback keeps synthetic
    graph generation testable even before OSMnx is installed.
    """
    output_path = Path(filepath).expanduser().resolve()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    normalized = normalize_graph(graph)
    report = validate_graph(normalized)
    if not report["valid"]:
        raise ValueError("Graph validation failed: " + "; ".join(report["errors"]))

    if prefer_osmnx:
        try:
            import osmnx as ox  # type: ignore[import-not-found]
        except ImportError:
            ox = None
        if ox is not None:
            ox.io.save_graphml(normalized, filepath=output_path)
            return output_path

    nx.write_graphml(_graphml_compatible_copy(normalized), output_path, encoding="utf-8")
    return output_path


def load_graphml(filepath: str | Path, *, prefer_osmnx: bool = True) -> nx.MultiDiGraph:
    """Load a GraphML graph and normalize it to the shared project format."""
    input_path = Path(filepath).expanduser().resolve()
    if not input_path.is_file():
        raise FileNotFoundError(f"GraphML file not found: {input_path}")

    graph: nx.Graph
    if prefer_osmnx:
        try:
            import osmnx as ox  # type: ignore[import-not-found]
        except ImportError:
            ox = None
        if ox is not None:
            graph = ox.io.load_graphml(filepath=input_path)
        else:
            graph = nx.read_graphml(input_path, force_multigraph=True)
    else:
        graph = nx.read_graphml(input_path, force_multigraph=True)

    return normalize_graph(graph)


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Validate a project's GraphML map.")
    parser.add_argument("graphml", help="Path to a GraphML map")
    args = parser.parse_args()
    loaded_graph = load_graphml(args.graphml)
    print(json.dumps(validate_graph(loaded_graph), ensure_ascii=False, indent=2))
